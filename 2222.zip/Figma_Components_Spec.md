
# Unified PTW — Figma Components Spec (v1)
Generated: 2026-03-02 02:33 UTC

## Global
- Grid: 12 columns, 8px base spacing, 1440 px desktop frame.
- Auto Layout: vertical stacks with 8/12/16 spacing; content areas use padding 16/24.
- Design Tokens: import `ptw_design_tokens.json` via Figma Tokens plugin.

## Frames
1. **PTW Core (Desktop 1440x1024)**
   - Header (App title + PTW status pill)
   - Card: Permit Metadata (Requestor, PTW-SO, Procedure, Purpose)
   - Card: Machine (Type, Number, Duration, Start/End, Multi-shift)
   - Card: Classification & Modules
     - `Space Classification` (Radio: None | Confined Space | Hazardous Space)
     - `Permit Types` (Chips: RMF, Thorium, EMO Decouple)
   - Footer actions: Save Draft, Submit for Approval

2. **Modules (Conditional Pane)**
   - RMF Module: Buddy, Temp < 38°C (switch), Barricades/Signage, Ventilation, PPE, LOTO Locations
   - Thorium Module: Laser off ≥30 min, Ventilation, Plastic/IPA/Fence 2m, Optic ID, 12Nc, Label, Training dates, EHS 1446-37 Ack
   - Confined Module: Roles (Supervisor/Attendant/Entrant/Tester), Comms, ERT, Extraction, Gas Device meta
   - Hazardous Module: Roles & Comms, Extraction, ERT note
   - EMO Module: Terminate, Stop Ops/Remote, Safety Interface Verify (pre/post), LOTO H₂/Ar/CO₂ light/N₂, OBST transfer, Notifications

3. **Gas Console**
   - Initial Release (required)
   - Readings table: Timestamp | O₂ % | CO₂ % | CO ppm | Within range ✓/✗
   - Timer pill: “Next reading due in 15:00”

4. **Review & Submit**
   - Summary of Core + Visible Modules
   - Validation list with anchors to fields
   - Approver preview

## Components
- PTW Card (Base) → Title, subtitle, slot for content
- Field Row (Label + Control + Help)
- Status Pill (Draft | Submitted | Approved | Rejected)
- Module Tabs (RMF | Thorium | Confined | Hazardous | EMO)
- Data Table (Gas Readings)
- Buttons: Primary, Secondary, Tertiary

## Interactions
- When `Space Classification` changes, hide other space module and reset hidden fields.
- If RMF selected → require Buddy, Temp < 38°C, Barricades before submit.
- If Thorium selected → require Laser off ≥30 min, Ventilation, Optic ID, 12Nc, Training valid, EHS 1446-37.
- If Confined/Hazardous → require Initial Release and show Gas Console.
- If EMO → require Terminate, Stop Ops/Remote, Safety Verifications, LOTO map.

