
# Unified PTW — Pilot Build (SAY704)
Generated: 2026-03-02 02:33 UTC

## Import order
1. Run SharePoint provisioning script (lists + lookups + folders).
2. Upload mapping workbook to /Documents/Design/Permits.
3. Import CSV sample data:
   - PTW_Core_sample.csv
   - PTW_RMF_sample.csv
   - PTW_Confined_sample.csv
   - PTW_EMO_sample.csv
   - PTW_Gas_Readings_sample.csv
4. Open Power Apps and connect to the lists; enable conditional visibility per spec.
5. Build Approval flow using PTW_Approval_Flow_Template.json as the guardrail spec.
6. Generate Word template and PDF output; test with the sample PTW ID=1.

## Expected scenario
- Permit Types: RMF + EMO Decouple
- Space Classification: Confined Space (exclusive)
- Machine: SAY704 (EUV)
- EMO decouple hard gates must pass; RMF buddy/temp/barricades must pass; Confined Space requires initial + 15-min gas readings.

## Figma
- Import `ptw_design_tokens.json` using the Figma Tokens plugin.
- Follow layout in `Figma_Components_Spec.md` and wireframe reference image `Wireframe_Core_Screen.png`.
