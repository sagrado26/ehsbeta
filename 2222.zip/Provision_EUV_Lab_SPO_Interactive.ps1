#requires -Modules PnP.PowerShell
<#
Interactive variant: Creates the EUV Lab document library structure and SharePoint Lists for Unified PTW.
- Library path: /Shared Documents/Design/Permits
- Lists: PTW – Core, RMF/Thorium/Confined/Hazardous/EMO modules, Gas Measurements
Confined/Hazardous Space are mutually exclusive via single-choice column on Core.
#>

param(
    [Parameter(Mandatory=$true)][string]$SiteUrl
)

# 0) Connect
Connect-PnPOnline -Url $SiteUrl -Interactive

# 1) Ensure folder structure in Default Document Library
$docLib = Get-PnPList -Identity "Documents"
if (-not $docLib) { throw "Default 'Documents' library not found" }

$folders = @(
    "Design",
    "Design/Permits"
)
foreach ($f in $folders) {
    Ensure-PnPFolder -SiteRelativePath ("Shared Documents/" + $f) | Out-Null
}

Write-Host "Folders ensured: /Shared Documents/Design/Permits" -ForegroundColor Green

# Helper: Create list if not exists
function Ensure-PTWList {
    param(
        [string]$Title,
        [string]$Template = "GenericList"
    )
    $list = Get-PnPList -Identity $Title -ErrorAction SilentlyContinue
    if (-not $list) {
        New-PnPList -Title $Title -Template $Template -OnQuickLaunch:$true | Out-Null
        Write-Host "Created list: $Title" -ForegroundColor Yellow
    } else {
        Write-Host "List exists: $Title" -ForegroundColor Gray
    }
}

# Helper: Ensure field (supports basic types)
function Ensure-FieldText { param([string]$List,[string]$InternalName,[string]$DisplayName,[switch]$Multi,[switch]$Required)
    $type = if ($Multi) { "Note" } else { "Text" }
    $field = Get-PnPField -List $List -Identity $InternalName -ErrorAction SilentlyContinue
    if (-not $field) {
        if ($type -eq "Note") {
            Add-PnPField -List $List -DisplayName $DisplayName -InternalName $InternalName -Type Note -AddToDefaultView | Out-Null
        } else {
            Add-PnPField -List $List -DisplayName $DisplayName -InternalName $InternalName -Type Text -AddToDefaultView | Out-Null
        }
    }
    if ($Required) { Set-PnPField -List $List -Identity $InternalName -Values @{Required=$true} | Out-Null }
}

function Ensure-FieldChoice { param([string]$List,[string]$InternalName,[string]$DisplayName,[string[]]$Choices,[switch]$Multi,[switch]$Required)
    $type = if ($Multi) { "MultiChoice" } else { "Choice" }
    $field = Get-PnPField -List $List -Identity $InternalName -ErrorAction SilentlyContinue
    if (-not $field) {
        Add-PnPField -List $List -DisplayName $DisplayName -InternalName $InternalName -Type $type -Choices $Choices -AddToDefaultView | Out-Null
    }
    if ($Required) { Set-PnPField -List $List -Identity $InternalName -Values @{Required=$true} | Out-Null }
}

function Ensure-FieldYesNo { param([string]$List,[string]$InternalName,[string]$DisplayName,[switch]$Required)
    $field = Get-PnPField -List $List -Identity $InternalName -ErrorAction SilentlyContinue
    if (-not $field) {
        Add-PnPField -List $List -DisplayName $DisplayName -InternalName $InternalName -Type Boolean -AddToDefaultView | Out-Null
    }
    if ($Required) { Set-PnPField -List $List -Identity $InternalName -Values @{Required=$true} | Out-Null }
}

function Ensure-FieldNumber { param([string]$List,[string]$InternalName,[string]$DisplayName,[switch]$Required)
    $field = Get-PnPField -List $List -Identity $InternalName -ErrorAction SilentlyContinue
    if (-not $field) {
        Add-PnPField -List $List -DisplayName $DisplayName -InternalName $InternalName -Type Number -AddToDefaultView | Out-Null
    }
    if ($Required) { Set-PnPField -List $List -Identity $InternalName -Values @{Required=$true} | Out-Null }
}

function Ensure-FieldDate { param([string]$List,[string]$InternalName,[string]$DisplayName,[switch]$Required)
    $field = Get-PnPField -List $List -Identity $InternalName -ErrorAction SilentlyContinue
    if (-not $field) {
        Add-PnPField -List $List -DisplayName $DisplayName -InternalName $InternalName -Type DateTime -AddToDefaultView | Out-Null
    }
    if ($Required) { Set-PnPField -List $List -Identity $InternalName -Values @{Required=$true} | Out-Null }
}

function Ensure-FieldUser { param([string]$List,[string]$InternalName,[string]$DisplayName,[switch]$Multi,[switch]$Required)
    $type = if ($Multi) { "UserMulti" } else { "User" }
    $field = Get-PnPField -List $List -Identity $InternalName -ErrorAction SilentlyContinue
    if (-not $field) {
        Add-PnPField -List $List -DisplayName $DisplayName -InternalName $InternalName -Type $type -AddToDefaultView | Out-Null
    }
    if ($Required) { Set-PnPField -List $List -Identity $InternalName -Values @{Required=$true} | Out-Null }
}

function Ensure-FieldLookup { param([string]$List,[string]$InternalName,[string]$DisplayName,[string]$LookupList,[string]$LookupField="Title",[switch]$Multi,[switch]$Required)
    $field = Get-PnPField -List $List -Identity $InternalName -ErrorAction SilentlyContinue
    if (-not $field) {
        Add-PnPField -List $List -DisplayName $DisplayName -InternalName $InternalName -Type Lookup -LookupList $LookupList -LookupField $LookupField -AddToDefaultView | Out-Null
    }
    if ($Required) { Set-PnPField -List $List -Identity $InternalName -Values @{Required=$true} | Out-Null }
}

# 2) Ensure lists
$lists = @(
    "PTW – Core",
    "PTW – RMF Module",
    "PTW – Thorium Module",
    "PTW – Confined Space Module",
    "PTW – Hazardous Space Module",
    "PTW – EMO Decouple Module",
    "PTW – Gas Measurements"
)
foreach ($l in $lists) { Ensure-PTWList -Title $l }

# 3) Columns — Core
$L = "PTW – Core"
Ensure-FieldText  -List $L -InternalName "PTWSO" -DisplayName "PTW-SO" -Required
Ensure-FieldChoice -List $L -InternalName "PermitTypes" -DisplayName "Permit Types" -Choices @("RMF","Thorium","EMO Decouple") -Multi -Required
Ensure-FieldChoice -List $L -InternalName "SpaceClassification" -DisplayName "Space Classification" -Choices @("None","Confined Space","Hazardous Space")
Ensure-FieldUser  -List $L -InternalName "Requestor" -DisplayName "Requestor" -Required
Ensure-FieldText  -List $L -InternalName "RequestorPhone" -DisplayName "Requestor Phone" -Required
Ensure-FieldText  -List $L -InternalName "ProcedureNames" -DisplayName "Procedure Names" -Multi -Required
Ensure-FieldText  -List $L -InternalName "Purpose" -DisplayName "Purpose" -Multi -Required
Ensure-FieldChoice -List $L -InternalName "CustomerFab" -DisplayName "Customer & Fab" -Choices @("F34","F42","Other") -Required
Ensure-FieldChoice -List $L -InternalName "MachineType" -DisplayName "Machine Type" -Choices @("EUV","Source","Scanner","Other") -Required
Ensure-FieldText  -List $L -InternalName "MachineNumber" -DisplayName "Machine Number" -Required
Ensure-FieldYesNo -List $L -InternalName "CustomerNotified" -DisplayName "Customer Notified"
Ensure-FieldText  -List $L -InternalName "CustomerContact" -DisplayName "Customer Contact"
Ensure-FieldNumber -List $L -InternalName "DurationHrs" -DisplayName "Duration (hrs)"
Ensure-FieldDate  -List $L -InternalName "StartDT" -DisplayName "Start" -Required
Ensure-FieldDate  -List $L -InternalName "EndDT" -DisplayName "End" -Required
Ensure-FieldYesNo -List $L -InternalName "MultipleShifts" -DisplayName "Multiple Shifts"
Ensure-FieldUser  -List $L -InternalName "Personnel" -DisplayName "Personnel" -Multi -Required
Ensure-FieldText  -List $L -InternalName "HazardsSummary" -DisplayName "Hazards Summary" -Multi
Ensure-FieldUser  -List $L -InternalName "EHSSignPerson" -DisplayName "EHS Sign-off (Person)"
Ensure-FieldDate  -List $L -InternalName "EHSSignDate" -DisplayName "EHS Sign-off (Date)"
Ensure-FieldUser  -List $L -InternalName "MgrSignPerson" -DisplayName "Responsible Manager (Person)"
Ensure-FieldDate  -List $L -InternalName "MgrSignDate" -DisplayName "Responsible Manager (Date)"

# 4) Helper to add PTW ID lookup to modules
function Ensure-PTWLookup {
    param([string]$ChildList)
    $field = Get-PnPField -List $ChildList -Identity "PTWID" -ErrorAction SilentlyContinue
    if (-not $field) {
        Add-PnPField -List $ChildList -DisplayName "PTW ID" -InternalName "PTWID" -Type Lookup -LookupList "PTW – Core" -LookupField "ID" -AddToDefaultView | Out-Null
    }
}

$moduleLists = @("PTW – RMF Module","PTW – Thorium Module","PTW – Confined Space Module","PTW – Hazardous Space Module","PTW – EMO Decouple Module")
foreach ($m in $moduleLists) { Ensure-PTWLookup -ChildList $m }
Ensure-PTWLookup -ChildList "PTW – Gas Measurements"

Write-Host "Provisioning complete." -ForegroundColor Green
